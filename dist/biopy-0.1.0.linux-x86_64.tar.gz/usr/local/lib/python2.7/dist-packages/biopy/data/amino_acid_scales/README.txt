- aaindex1

Contains amino acid scales obtained from:
ftp://ftp.genome.jp/pub/db/community/aaindex/aaindex1

Information about the amino acid scales can be found on:
http://www.genome.jp/aaindex/



- georgiev.txt

Contains scales obtained from Georgiev paper. These are 19 scales
that 'capture' all scales in the aaindex data base.
