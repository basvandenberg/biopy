"""
.. module:: biopy
   :platform: Unix
   :synopsis: A little Swiss Army knife for bioinformaticians.

.. moduleauthor:: Bastiaan van den Berg <b.a.vandenberg@gmail.com>
"""

__version__ = '0.1.1'
