- aaindex2

Contains amino acid distance matrices obtained from:
ftp://ftp.genome.jp/pub/db/community/aaindex/aaindex2

Information about the amino acid scales can be found on:
http://www.genome.jp/aaindex/
